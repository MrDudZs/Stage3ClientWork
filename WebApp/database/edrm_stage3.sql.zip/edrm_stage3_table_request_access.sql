
-- --------------------------------------------------------

--
-- Table structure for table `request_access`
--

CREATE TABLE `request_access` (
  `id` int(11) NOT NULL,
  `doc_id` int(11) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','declined') DEFAULT 'pending',
  `request_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `request_access`
--

INSERT INTO `request_access` (`id`, `doc_id`, `staffid`, `request_date`, `status`, `request_time`) VALUES
(40, 40, 6, '2024-04-15 01:01:24', 'approved', '00:00:00');
