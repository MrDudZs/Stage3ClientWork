
-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `doc_id` int(11) NOT NULL,
  `change_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`id`, `date`, `time`, `staffid`, `doc_id`, `change_description`) VALUES
(110, NULL, NULL, 6, 29, 'Approved access for document ID: 29'),
(111, NULL, NULL, 6, 30, 'Approved access for document ID: 30'),
(112, '2024-04-15', '02:34:16', 6, 38, 'Uploaded document: EDRMS - Mgmt Dashboard (Sample).pdf'),
(113, '2024-04-15', '02:34:39', 6, 38, 'Clicked modify for document ID 38 by user ID 6'),
(114, '2024-04-15', '02:34:39', 6, 38, 'Clicked view for document ID 38 by user ID 6'),
(115, '2024-04-15', '02:34:49', 6, 38, 'Clicked view for document ID 38 by user ID 6'),
(116, '2024-04-15', '02:34:50', 6, 38, 'Clicked modify for document ID 38 by user ID 6'),
(117, '2024-04-15', '02:36:15', 6, 39, 'Uploaded document: EDRMS - Mgmt Dashboard (Sample).pdf'),
(118, '2024-04-15', '02:36:24', 6, 39, 'Clicked modify for document ID 39 by user ID 6'),
(119, '2024-04-15', '02:36:27', 6, 39, 'Clicked view for document ID 39 by user ID 6'),
(120, '2024-04-15', '02:36:57', 7, 40, 'Uploaded document: EDRMS - Mgmt Dashboard (Sample).png'),
(121, '2024-04-15', '02:37:20', 7, 41, 'Uploaded document: ELECTRONIC DOCUMENT AND RECORDS MANAGEMENT SYSTEM (EDRMS) 2024 V2 (1).pptx'),
(122, '2024-04-15', '02:37:43', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(123, '2024-04-15', '02:37:43', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(124, '2024-04-15', '02:41:04', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(125, '2024-04-15', '02:41:44', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(126, '2024-04-15', '02:41:44', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(127, '2024-04-15', '02:41:47', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(128, '2024-04-15', '02:42:03', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(129, '2024-04-15', '02:42:03', 7, 41, 'Added user with staffid: 6 for document ID 41'),
(130, '2024-04-15', '02:59:08', 11, 42, 'Uploaded document: EDRMS - Mgmt Dashboard (Sample).png'),
(131, NULL, NULL, 7, 40, 'Approved access for document ID: 40'),
(132, '2024-04-15', '03:03:42', 6, 41, 'Clicked modify for document ID 41 by user ID 6'),
(133, '2024-04-15', '03:03:47', 6, 41, 'Clicked view for document ID 41 by user ID 6'),
(134, '2024-04-15', '03:09:01', 8, 43, 'Uploaded document: EDRMS - Mgmt Dashboard (Sample).pdf'),
(135, '2024-04-15', '03:09:35', 9, 44, 'Uploaded document: ELECTRONIC DOCUMENT AND RECORDS MANAGEMENT SYSTEM (EDRMS) 2024 V2 (1).pptx'),
(136, '2024-04-15', '03:09:58', 10, 45, 'Uploaded document: ELECTRONIC DOCUMENT AND RECORDS MANAGEMENT SYSTEM (EDRMS) 2024 V2 (1).pptx');
