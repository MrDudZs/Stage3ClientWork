
-- --------------------------------------------------------

--
-- Table structure for table `shared_access`
--

CREATE TABLE `shared_access` (
  `shared_id` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `access_granted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
