
-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffid` int(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_suspended` tinyint(4) NOT NULL,
  `job_role` varchar(255) DEFAULT NULL,
  `permission_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffid`, `first_name`, `surname`, `email`, `dob`, `password`, `is_suspended`, `job_role`, `permission_id`, `department_id`) VALUES
(5, 'SYSTEM', 'ADMIN', 'm@t.t', '0001-01-01', '$2y$10$TtviYWs.8jkyzbPE26AQ9eAPnXEJaYhsU3Q/iXHCootJlkIRDdD9C', 0, '', 1, NULL),
(6, 'HEAD of', 'FINANCE', 'm@t.t', '1111-11-11', '$2y$10$Nqjb0P3tJUAIJ9ACf90Q.eJrPctaXlNe7pKZzbpY9a5W99HDnyY3K', 0, 'Head of Finance', 2, 1),
(7, 'FINANCE', 'MANAGER', 'm@t.t', '1111-11-11', '$2y$10$lmXC9XEIG8oM97Bt7CVr6OPc4koUaF3PFYE1r7Bkyw8NCxmaDg7wm', 0, 'Finance Manager', 3, 1),
(8, 'FINANCE', 'OFFICER', 'm@t.t', '2024-04-12', '$2y$10$mbHHtK.8nPKuUIErnD3hcO48SM2lnudS6uPYfPkC75jusbQhGh4NC', 0, 'Finance Officer', 4, 1),
(9, 'OTHER', 'USER', 'm@t.t', '2024-04-12', '$2y$10$VR9SBMmRvSFChzHg1fZAMe.vse/ayQBlViq1XaJsxewFO4CgcfrM2', 0, 'Human Resources', 5, 18),
(10, 'FINANCE', 'OFFICER', 'test@test.test', '2024-04-12', '$2y$10$ZXyIiAUsVRttImMuRxCMZ.XEtT7EAQNGqiTO8xMUWydBwdOzUeJLq', 0, 'Finance Officer', 4, 1),
(11, 'Test', 'Test', 'test@test.test', '2024-04-13', '$2y$10$DXoaey0NdbbY9xPzrDiBdOyxypydW2hQqixcUCO9iCT3yCh594zT6', 0, 'HR', 5, 18);
