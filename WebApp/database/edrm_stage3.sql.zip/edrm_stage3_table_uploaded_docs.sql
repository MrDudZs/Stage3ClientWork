
-- --------------------------------------------------------

--
-- Table structure for table `uploaded_docs`
--

CREATE TABLE `uploaded_docs` (
  `doc_id` int(11) NOT NULL,
  `doc_name` varchar(255) NOT NULL,
  `doc_owner` varchar(255) NOT NULL,
  `doc_severity` enum('LOW','MEDIUM','HIGH') NOT NULL,
  `upload_date` date NOT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `file_status` int(11) DEFAULT 0,
  `doc_class` varchar(255) DEFAULT NULL,
  `doc_due` date DEFAULT NULL,
  `upload_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uploaded_docs`
--

INSERT INTO `uploaded_docs` (`doc_id`, `doc_name`, `doc_owner`, `doc_severity`, `upload_date`, `staff_id`, `file_status`, `doc_class`, `doc_due`, `upload_time`) VALUES
(39, 'EDRMS - Mgmt Dashboard (Sample).pdf', 'HEAD of FINANCE', 'MEDIUM', '2024-04-15', 6, 1, 'Budget', '2024-04-23', '02:36:15'),
(40, 'EDRMS - Mgmt Dashboard (Sample).png', 'FINANCE MANAGER', 'MEDIUM', '2024-04-15', 7, 0, 'Budget', '2024-04-24', '02:36:57'),
(41, 'ELECTRONIC DOCUMENT AND RECORDS MANAGEMENT SYSTEM (EDRMS) 2024 V2 (1).pptx', 'FINANCE MANAGER', 'MEDIUM', '2024-04-15', 7, 0, 'Budget', '2024-04-23', '02:37:20'),
(42, 'EDRMS - Mgmt Dashboard (Sample).png', 'Test Test', 'LOW', '2024-04-15', 11, 0, 'Budget', '2024-04-26', '02:59:08'),
(43, 'EDRMS - Mgmt Dashboard (Sample).pdf', 'FINANCE OFFICER', 'LOW', '2024-04-15', 8, 0, 'Budget', '2024-04-25', '03:09:01'),
(44, 'ELECTRONIC DOCUMENT AND RECORDS MANAGEMENT SYSTEM (EDRMS) 2024 V2 (1).pptx', 'OTHER USER', 'LOW', '2024-04-15', 9, 0, 'Procurement', '2024-04-30', '03:09:35'),
(45, 'ELECTRONIC DOCUMENT AND RECORDS MANAGEMENT SYSTEM (EDRMS) 2024 V2 (1).pptx', 'FINANCE OFFICER', 'MEDIUM', '2024-04-15', 10, 0, 'Budget', '2024-05-02', '03:09:58');
