
-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_name` varchar(255) NOT NULL,
  `department_location` varchar(255) NOT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_name`, `department_location`, `department_id`) VALUES
('FINANCE', 'Building A', 1),
('Sales', 'Location A', 2),
('Marketing', 'Location B', 3),
('Human Resources', 'Location C', 4),
('Operations', 'Location A', 5),
('Customer Service', 'Location B', 6),
('Research and Development', 'Location C', 7),
('Information Technology', 'Location A', 8),
('Administration', 'Location B', 9),
('Legal', 'Location C', 10),
('Supply Chain', 'Location A', 11),
('Product Management', 'Location B', 12),
('Logistics', 'Location C', 13),
('Quality Assurance', 'Location A', 14),
('Engineering', 'Location B', 15),
('Sales', 'Location B', 16),
('Marketing', 'Location C', 17),
('Human Resources', 'Location A', 18),
('Operations', 'Location C', 19),
('Customer Service', 'Location A', 20),
('Research and Development', 'Location B', 21),
('Information Technology', 'Location C', 22),
('Administration', 'Location A', 23),
('Legal', 'Location B', 24),
('Supply Chain', 'Location A', 25),
('Product Management', 'Location C', 26),
('Logistics', 'Location B', 27),
('Quality Assurance', 'Location C', 28),
('Engineering', 'Location A', 29),
('Sales', 'Location C', 30),
('Marketing', 'Location A', 31),
('Human Resources', 'Location B', 32),
('Operations', 'Location A', 33),
('Customer Service', 'Location B', 34),
('Research and Development', 'Location C', 35),
('Information Technology', 'Location A', 36),
('Administration', 'Location B', 37),
('Legal', 'Location C', 38),
('Supply Chain', 'Location A', 39),
('Product Management', 'Location B', 40),
('Logistics', 'Location C', 41),
('Quality Assurance', 'Location A', 42),
('Engineering', 'Location B', 43),
('Finance', 'Location C', 44),
('Finance', 'Location B', 45);
